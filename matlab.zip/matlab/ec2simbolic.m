%Implementarea modelului virusului HIV cu prezen?? de infec?ii duble -
%reprezentare simbolica
syms t
syms T(t) Tm(t)  Tw(t) Tmw(t)
ro=0.5;
Km=2.0;
Kw=0.8;
Kr=0.9;
roM=0.8;
Qm=3.05;
roW=9.0;
roMW=4.5;
Qw=0.2;
eq1= diff(T,t) == (ro - Km*Tm - Kw*Tw - Kr*Tmw)*T;
eq2= diff(Tm,t) == (roM+Km*T-Qm*Tw)*Tm+0.25*Kr*Tmw*T;
eq3=diff(Tw,t) == (roW+Km*T-roW*Tm)*Tw+0.25*Kr*Tmw*T;
eq4=diff(Tmw,t)== (roMW+0.5*Kr*T)*Tmw+(Qm+Qw)*Tw*Tm;
sol1= dsolve(eq1);
sol2=dsolve(eq2);
sol3=dsolve(eq3);
sol4=dsolve(eq4);
disp(simplify(sol1));
pretty(sol1);
pretty(sol2);
pretty(sol3);
pretty(sol4);
