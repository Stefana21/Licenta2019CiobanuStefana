%Implementarea modelului virusului HIV cu prezen?? de infec?ii duble -
%reprezentare numerica + grafica 
ro=0.5;
Km=2.0;
Kw=0.8;
Kr=0.9;
roM=0.8;
Qm=3.05;
roW=9.0;
roMW=4.5;
Qw=0.2;
T=0.5;
Tm=0.9;
Tw=0.2;
Tmw=0.01;
interval=[0 1.5];
[interval,x]=ode45(@diff_hiv,interval,[T Tm Tw Tmw],[],[ro Km Kw Kr roM Qm roW roMW Qw]);
T=x(:,1); Tm=x(:,2); Tw=x(:,3); Tmw=x(:,4);
subplot(2,2,1);
plot(interval,T,'g');
title('Celule neinfectate');
subplot(2,2,2);
plot(interval, Tm,'k');
title('Celule infectate cu virusul mutant');
subplot(2,2,3);
plot(interval,Tw,'r');
title('Celule infectate cu virusul de tip salbatic');
subplot(2,2,4);
plot (interval,Tmw,'p');
title('Infectie dubla');
grid on;
axis([0 180 0 8]);
function dx=diff_hiv(~,x,parameter)
ro=parameter(1); Km=parameter(2); Kw=parameter(3); Kr=parameter(4); roM=parameter(5); Qm=parameter(6); roW=parameter(7); roMW=parameter(8); Qw=parameter(9);
T=x(1); Tm=x(2); Tw=x(3); Tmw=x(4);
dx=zeros(4,1);
dx(1)= (ro - Km*Tm - Kw*Tw - Kr*Tmw)*T;
dx(2)= (roM+Km*T-Qm*Tw)*Tm+0.25*Kr*Tmw*T;
dx(3)= (roW+Km*T-roW*Tm)*Tw+0.25*Kr*Tmw*T;
dx(4)= (roMW+0.5*Kr*T)*Tmw+(Qm+Qw)*Tw*Tm;
end







