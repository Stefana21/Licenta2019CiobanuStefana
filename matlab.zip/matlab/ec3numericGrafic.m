%Implementarea modelului imunit??ii la respingerea unui transplant -
%reprezentare grafica + numerica
Ke=1;
Kxec=1.5;
Kxe=1;
Kc=0.3;
KcacF=2.92;
Kxce=1;
Kst=1;
Ks=2;
Kxsc=0.15;
Kxc=1;
Cl=0.3;
Sstar=7;
Kls=1.5;
Kxlc=0.7;
Kxl=0.7;
L=1;
E=1.38;
S=0;
Ce=1.1;
l=0;
interval=[0 8];
[interval,x]=ode45(@diff_transplant,interval,[E Ce  S  l],[],[Ke Kxec Kxe Kc KcacF Kxce Kst Ks Kxsc Kxc Cl Sstar Kls Kxlc Kxl L]);
disp(newline);
disp(E);
disp(Ce);
disp(S);
disp(l);
E=x(:,1); Ce=x(:,2); S=x(:,3); l=x(:,4);
subplot(2,2,1);
plot(interval,E,'g');
title('Antigen E');
xlabel('ani');
ylabel('E - microg/ l');
subplot(2,2,2);
plot(interval, Ce,'k');
title('T-limfocite');
xlabel('ani');
ylabel('Ce - celula/ microl* 10^3');
subplot(2,2,3);
plot(interval,S,'r');
title('Antigen S');
xlabel('ani');
ylabel('S - microg/ l');
subplot(2,2,4);
plot (interval,l,'b');
title('Antigen L');
xlabel('ani');
ylabel('L - microg/ l');
grid on;
axis([0 60 0 1]);
axis([0 60 0 3]);
axis([0 60 0 10]);
axis([0 60 0 10]);
function dx=diff_transplant(~,x,parameter)
Ke=parameter(1); Kxec=parameter(2); Kxe=parameter(3); Kc =parameter(4); KcacF =parameter(5); Kxce=parameter(6); Kst=parameter(7); Ks=parameter(8); Kxsc=parameter(9); Kxc=parameter(10); Cl=parameter(11); Sstar=parameter(12); Kls=parameter(13); Kxlc=parameter(14); Kxl=parameter(15); L=parameter(16);
E=x(1); Ce=x(2); S=x(3); l=x(4);
dx=zeros(4,1);
dx(1)= Ke - Kxec*Ce*E-Kxe*E;
dx(2)= Kc + KcacF*Ce*E- Kxce*E*Ce-Kxc*Ce;
dx(3)= Kst + Ks*S*(1-(S/Sstar))-Kxsc*Cl*S;
dx(4)= Kls* S- Kxlc*Cl-Kxl*L;
end







