%Implementarea modelului de cre?tere a unei tumori - reprezentarea simbolica

syms t
syms x(t) 
alfa=0.894;
beta=2.67;

eq1= diff(x,t) == alfa*t-beta*(x*x);


sol1= dsolve(eq1);


disp(simplify(sol1));

pretty(sol1);
