%Implementarea modelului imunit??ii la respingerea unui transplant - reprezentarea simbolica

syms t
syms E(t) Ce(t)  S(t)  l(t)
Ke=1;
Kxec=1.5;
Kxe=1;
Kc=0.3;
KcacF=2.92;
Kxce=1;
Kst=1;
Ks=2;
Kxsc=0.15;
Kxc=1;
Cl=0.3;
Sstar=7;
Kls=1.5;
Kxlc=0.7;
Kxl=0.7;
L=1;
eq1= diff(E,t) == Ke - Kxec*Ce*E-Kxe*E;
eq2= diff(Ce,t) == Kc + KcacF*Ce*E- Kxce*E*Ce-Kxc*Ce;
eq3=diff(S,t) == Kst + Ks*S*(1-(S/Sstar))-Kxsc*Cl*S;
eq4=diff(l,t)== Kls* S- Kxlc*Cl-Kxl*L;
sol1= dsolve(eq1);
sol2=dsolve(eq2);
sol3=dsolve(eq3);
sol4=dsolve(eq4);
disp(simplify(sol1));
disp(simplify(sol2));
disp(simplify(sol3));
disp(simplify(sol4));
pretty(sol1);